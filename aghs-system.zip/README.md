demo with laravel and blade
 
