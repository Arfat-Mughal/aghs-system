<link href="https://fonts.googleapis.com/css?family=Work+Sans:100,200,300,400,500,600,700,800,900" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Fredericka+the+Great" rel="stylesheet">

<link rel="stylesheet" href="{{asset('web_assets/css/open-iconic-bootstrap.min.css')}}">
<link rel="stylesheet" href="{{asset('web_assets/css/animate.css')}}">

<link rel="stylesheet" href="{{asset('web_assets/css/owl.carousel.min.css')}}">
<link rel="stylesheet" href="{{asset('web_assets/css/owl.theme.default.min.css')}}">
<link rel="stylesheet" href="{{asset('web_assets/css/magnific-popup.css')}}">

<link rel="stylesheet" href="{{asset('web_assets/css/aos.css')}}">

<link rel="stylesheet" href="{{asset('web_assets/css/ionicons.min.css')}}">

<link rel="stylesheet" href="{{asset('web_assets/css/flaticon.css')}}">
<link rel="stylesheet" href="{{asset('web_assets/css/icomoon.css')}}">
<link rel="stylesheet" href="{{asset('web_assets/css/style.css')}}">
