<?php $__env->startSection('content'); ?>
    <!-- MAIN CONTENT-->
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="overview-wrap">
                            <h2 class="title-1">Students</h2>
                            <a href="<?php echo e(route('add_student')); ?>"  class="au-btn au-btn-icon au-btn--blue">
                                <i class="zmdi zmdi-plus"></i>add student</a>
                        </div>
                    </div>
                </div>
                <div class="mt-2">
                    <table class="table table-striped" id="table">
                        <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Image</th>
                            <th scope="col">Roll NO</th>
                            <th scope="col">Student Name</th>
                            <th scope="col">Father Name</th>
                            <th scope="col">Phone</th>
                            <th scope="col">Cell</th>
                            <th scope="col">Class</th>
                            <th scope="col">Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($student->id); ?></th>
                            <td><img src="<?php echo e($student->path); ?>" alt="<?php echo e($student->name); ?>" height="40px" width="60px" class="rounded"></td>
                            <td><?php echo e($student->addmission_no); ?></td>
                            <td><?php echo e($student->name); ?></td>
                            <td><?php echo e($student->father_name); ?></td>
                            <td><?php echo e($student->phone); ?></td>
                            <td><?php echo e($student->cell); ?></td>
                            <td><?php echo e($student->grade->name); ?></td>
                            <td><div class="btn-group" role="group">
                                    <button id="btnGroupDrop1" type="button" class="btn btn-info btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        Actions
                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="btnGroupDrop1">
                                        <a class="dropdown-item" href="<?php echo e(route('view_student',$student->id)); ?>" target="_blank">View</a>
                                        <a class="dropdown-item" href="<?php echo e(route('update_student',$student->id)); ?>">Update</a>
                                        <form method="POST" action="<?php echo e(route('delete_student', [ 'id'=> $student->id ])); ?>">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="id" value=<?php echo e($student->id); ?>>
                                            <button type="submit" class="dropdown-item">Delete
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aghs-system\resources\views/admin/students.blade.php ENDPATH**/ ?>