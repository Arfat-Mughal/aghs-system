<script src="<?php echo e(asset('web_assets/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('web_assets/js/jquery-migrate-3.0.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('web_assets/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('web_assets/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('web_assets/js/jquery.easing.1.3.js')); ?>"></script>
<script src="<?php echo e(asset('web_assets/js/jquery.waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('web_assets/js/jquery.stellar.min.js')); ?>"></script>
<script src="<?php echo e(asset('web_assets/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('web_assets/js/jquery.magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(asset('web_assets/js/aos.js')); ?>"></script>
<script src="<?php echo e(asset('web_assets/js/jquery.animateNumber.min.js')); ?>"></script>
<script src="<?php echo e(asset('web_assets/js/scrollax.min.js')); ?>"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
<script src="<?php echo e(asset('web_assets/js/google-map.js')); ?>"></script>
<script src="<?php echo e(asset('web_assets/js/main.js')); ?>"></script>
<script type="text/javascript">
    $(window).load(function()
    {
        $('#myModal').modal('show');
    });
    $('#close_modal').onclick.modal('hide');

</script>
<?php /**PATH C:\xampp\htdocs\aghs-system\resources\views/includes/js.blade.php ENDPATH**/ ?>