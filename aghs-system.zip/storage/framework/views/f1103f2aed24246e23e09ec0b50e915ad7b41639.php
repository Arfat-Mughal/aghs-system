<!-- MENU SIDEBAR-->
<aside class="menu-sidebar d-none d-lg-block">
    <div class="logo">
        <a href="#">
            <img src="<?php echo e(asset('admin_assets/images/icon/logo_179x52.png')); ?>" alt="Cool Admin"  height="52px" width="179px"/>
        </a>
    </div>
    <div class="menu-sidebar__content js-scrollbar1">
        <nav class="navbar-sidebar">
            <ul class="list-unstyled navbar__list">
                <li class="active has-sub">
                    <a class="js-arrow" href="<?php echo e(route('panel')); ?>">
                        <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                </li>
                <li>
                    <a href="<?php echo e(route('students')); ?>">
                        <i class="fas fa-copy"></i>Students</a>
                </li>
                <li>
                    <a href="<?php echo e(route('results')); ?>">
                        <i class="fas fa-chart-bar"></i>Results</a>
                </li>
                <li>
                    <a href="<?php echo e(route('slips')); ?>">
                        <i class="fas fa-table"></i>Roll No Slip's</a>
                </li>
                <li class="has-sub">
                    <a class="js-arrow open" href="#">
                        <i class="fas fa-trophy"></i>Certificates
                    </a>
                    <ul class="list-unstyled navbar__sub-list js-sub-list" style="display: block;">
                        <li>
                            <a href="<?php echo e(route('certificate_merit')); ?>"><i class="fas fa-address-book"></i>Certificate Of Merit</a>
                        </li>
                    </ul>
                </li>
            </ul>
        </nav>
    </div>
</aside>
<!-- END MENU SIDEBAR-->
<?php /**PATH C:\xampp\htdocs\aghs-system\resources\views/adminIncludes/sidebar.blade.php ENDPATH**/ ?>